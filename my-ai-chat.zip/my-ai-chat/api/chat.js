// Serverless backend: API key ekhane secret thake, browser e kokhono jay na.
const SYSTEM = "You are a helpful AI assistant. You are an expert programmer: write clean, correct, working code and explain briefly. Reply in the same language the user writes in.";

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const { messages } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) return res.status(400).json({ error: "Bad request" });

  // Abuse theke bachar jonno limit
  const safe = messages.slice(-20).map(m => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: String(m.content || "").slice(0, 8000),
  }));

  try {
    const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
      body: JSON.stringify({
        model: process.env.MODEL || "llama-3.3-70b-versatile",
        messages: [{ role: "system", content: SYSTEM }, ...safe],
        stream: true,
        max_tokens: 2048,
      }),
    });
    if (!r.ok) return res.status(r.status).json({ error: "Model busy ba limit shesh. Ektu pore try korun." });

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    const reader = r.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      res.write(value);
    }
    res.end();
  } catch (e) {
    res.status(500).json({ error: "Server error" });
  }
};
