# My AI Chat
Free, open-source ChatGPT-style chat app. Frontend: plain HTML. Backend: 1 serverless function (Groq free API + Llama 3.3 70B).

Run: set env var GROQ_API_KEY (get free at console.groq.com), then deploy on Vercel.
